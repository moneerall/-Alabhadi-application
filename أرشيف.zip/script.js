// بيانات وهمية للمستخدمين
let users = [
    {id:1, name:"أحمد علي", email:"ahmed@test.com"},
    {id:2, name:"سارة محمد", email:"sara@test.com"}
];

// عرض المستخدمين في صفحة users.html
function renderUsers() {
    const tbody = document.getElementById("userTable");
    if(tbody){
        tbody.innerHTML = "";
        users.forEach(user => {
            tbody.innerHTML += `
                <tr>
                    <td>${user.id}</td>
                    <td>${user.name}</td>
                    <td>${user.email}</td>
                    <td>
                        <button onclick="deleteUser(${user.id})">حذف</button>
                    </td>
                </tr>
            `;
        });
    }
}

// حذف مستخدم
function deleteUser(id){
    users = users.filter(u => u.id !== id);
    renderUsers();
}

// نموذج تسجيل مستخدم جديد
const registerForm = document.getElementById("registerForm");
if(registerForm){
    registerForm.addEventListener("submit", function(e){
        e.preventDefault();
        const name = document.getElementById("fullName").value;
        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;
        users.push({id: users.length+1, name:name, email:email});
        alert("تم تسجيل المستخدم بنجاح!");
        registerForm.reset();
        renderUsers();
    });
}

// عرض الإحصائيات
const userCount = document.getElementById("userCount");
const statUsers = document.getElementById("statUsers");
if(userCount) userCount.textContent = users.length;
if(statUsers) statUsers.textContent = users.length;

renderUsers();